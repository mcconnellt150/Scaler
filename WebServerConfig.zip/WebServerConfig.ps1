Write-Host "Installing Octopus Deploy DSC Extension..."
.\Install-OctopusDSC.ps1

Write-Host "Installing Chocolatey..."
.\install.ps1

Write-Host "Installing Roles..."
Import-Csv .\Roles.csv | foreach{Add-WindowsFeature $_.name  }

Write-Host "Installing webdeploy..."
choco install webdeploy /y

Write-Host "installing urlrewrite..."
choco install urlrewrite /y

if (-not (Test-Path "C:\Program Files\WindowsPowerShell\Modules\OctopusDSC")) {
    mkdir c:\temp -ErrorAction SilentlyContinue | Out-Null
    $client = new-object system.Net.Webclient
    $client.DownloadFile("https://github.com/OctopusDeploy/OctopusDSC/archive/master.zip","c:\temp\octopusdsc.zip")
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory("c:\temp\octopusdsc.zip", "c:\temp")
    cp -Recurse C:\temp\OctopusDSC-master\OctopusDSC "C:\Program Files\WindowsPowerShell\Modules\OctopusDSC"
}

Configuration WebServerConfig
{
    param ($ApiKey, $OctopusServerUrl, $Environments, $Roles, $MachinePolicy, $ListenPort, $CommsStyle)

    Import-DscResource -Module OctopusDSC

	Node ("localhost")
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install Application Initialization
		WindowsFeature AppInit
		{
			Ensure = "Present"
			Name = "Web-AppInit"
		}

		#Install Static Content
		WindowsFeature StaticContent
		{
			Ensure = "Present"
			Name = "Web-Static-Content"
		}

		#Install Dynamic Content Compression
		WindowsFeature DynamicContentCompression
		{
			Ensure = "Present"
			Name = "Web-Dyn-Compression"
		}
		
		#Install Static Content Compression
		WindowsFeature StaticContentCompression
		{
			Ensure = "Present"
			Name = "Web-Stat-Compression"
		}

		#Install IIS Web Server Management Console
		WindowsFeature WebServerManagementConsole
		{
			Name = "Web-Mgmt-Console"
			Ensure = "Present"
		}

	
		#Install Octopus Deploy Tentacle
		cTentacleAgent OctopusTentacle 
        { 
            Ensure = "Present"; 
            State = "Started"; 

            Name = "Tentacle";

            ApiKey = $ApiKey;
            OctopusServerUrl = $OctopusServerUrl;
            Environments = $Environments;
            Roles = $Roles;
			Policy = $MachinePolicy;
			CommunicationMode = "Poll";
	
            DefaultApplicationDirectory = "C:\Applications"
        }
	}
} 